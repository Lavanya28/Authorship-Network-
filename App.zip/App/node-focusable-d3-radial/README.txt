A Pen created at CodePen.io. You can find this one at https://codepen.io/Lavanya_Piramanayagam/pen/WzLmdO.

 This is a version of the Collapsible Tree. Click a node to make it the new focus point. Click the background to return to original state.